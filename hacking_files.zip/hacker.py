print("Main Hacker Banooga")
